import { useEffect, useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import api from './api/Post'
import Home from './Home'
import Search from './Search'
import AddPost from './AddPost'
import { format } from 'date-fns' 
import { DataProvider } from './Context/DataContext'
function App() {
  const [posts, setposts] = useState([])
  const [search,setsearch]=useState("")
  const [title,settitle]=useState("")
  const [body,setbody]=useState("")
useEffect(()=>
{
  const fetData=async()=>{
    const res=await api.get("/feedback")
    //console.log(res.data)
    setposts(res.data)
  }
  fetData()
},[]
)

const filteredPosts = posts.filter((post) =>
  post.title.toLowerCase().includes(search.toLowerCase())||
  post.body.toLowerCase().includes(search.toLowerCase())
);

const handleSubmit=async(e)=>{
  e.preventDefault()
  const id=(posts.length)?(Number(posts[posts.length-1].id)+1):1
  const datetime=format(new Date(),"MMMM dd, yyyy pp")
  //newObj={id:id,title:title,body:body,datetime:datetime}
  const newObj={id,title,datetime,body}
  await api.post("/feedback",newObj)
  const newList=[...posts,newObj]
  setposts(newList)
  settitle('')
  setbody('')
}


  return (
    <>
     <DataProvider>
     <Search search={search} setSearch={setsearch}/>
     <hr/>
     <AddPost title={title} setTitle={settitle} body={body} setBody={setbody} handleSubmit={handleSubmit}/>
     <Home posts={filteredPosts}/>
     </DataProvider>
    </>
    
  )
}

export default App
