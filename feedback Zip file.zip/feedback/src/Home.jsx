import React from 'react'
import { useContext } from 'react'
import DataContext from './Context/DataContext'
const Home=({posts})=>{
    const {num}=useContext(DataContext)
  return (
    <div>
        <h1>{num}</h1>
        {
        posts.map((post)=>
          <div key={post.id}>
          <h1>{post.title}</h1>
          <h3>{post.datetime}</h3>
          <p>{post.body}</p>
          <hr />
          </div>
        )
     }
    </div>
  )
}
export default Home