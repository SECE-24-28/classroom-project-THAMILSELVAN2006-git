/*const exp=require("express");
const cors=require("cors");
const app=exp();
const PORT=4000;

app.use(cors())
app.use(exp.json())

let courses=require('./data/db.json')

app.get('/api/courses',(req,res)=>
{
     res.json(courses)
})

app.get("/api/courses/:id",(req, res)=>
{
     const id=Number(req.params.id)
     const course=courses.find((c)=>c.cid===id)
     if(!course)
     {
         return res.status(404).json({message:"Course not found"})
     }
     res.json(course);
})

app.post('/api/courses',(req, res)=>
{
     const{cname,cdur}=req.body
     const cid=courses.length ? courses[courses.length-1].cid+1:1
     const newCourses={cid,cname,cdur}
     courses.push(newCourses)
     res.status(201).json(newCourses)
})


app.put("/api/courses/:id",(req, res)=>
{
     const id=Number(req.params.id)
     const{cname,cdur}=req.body
     let course=courses.find((c)=>c.cid===id)
     if(!course)
     {
         return res.status(404).json({message:"Course not found"})
     }
     
     course.cname=cname
     course.cdur=cdur
     res.json(course)
})

app.delete("/api/courses/:id",(req, res)=>
{
     const id=Number(req.params.id)
     courses=courses.filter((c)=>c.cid!==id)
     res.json({message:"Course deleted successfully"})
})

app.listen(PORT,()=>
{
     console.log(`Server is running on http://localhost:${PORT}`)
})*/

const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const Course = require("./Model/CourseModel");

const app = express();
const PORT = 4000;

app.use(cors());
app.use(express.json());

// MongoDB connection
mongoose.connect("mongodb://localhost:27017/mycourse")
.then(() => console.log("Connected to MongoDB"))
.catch(err => console.log(err));

/* ---------- ROUTES ---------- */

// Get all courses
app.get("/api/courses", async (req, res) => {
    try {
        const courses = await Course.find();
        res.json(courses);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Get course by ID
app.get("/api/courses/:id", async (req, res) => {
    try {
        const course = await Course.findById(req.params.id);
        if (!course) {
            return res.status(404).json({ message: "Course not found" });
        }
        res.json(course);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Add new course
app.post("/api/courses", async (req, res) => {
    try {
        const { title, duration } = req.body;
        const course = new Course({ title, duration });
        await course.save();
        res.status(201).json(course);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Update course
app.put("/api/courses/:id", async (req, res) => {
    try {
        const { title, duration } = req.body;
        const updatedCourse = await Course.findByIdAndUpdate(
            req.params.id,
            { title, duration },
            { new: true }
        );

        if (!updatedCourse) {
            return res.status(404).json({ message: "Course not found" });
        }

        res.json(updatedCourse);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Delete course
app.delete("/api/courses/:id", async (req, res) => {
    try {
        const deletedCourse = await Course.findByIdAndDelete(req.params.id);
        if (!deletedCourse) {
            return res.status(404).json({ message: "Course not found" });
        }
        res.json({ message: "Course deleted successfully" });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});