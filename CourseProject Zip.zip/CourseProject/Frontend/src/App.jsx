import { useEffect, useState } from 'react'

import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { getCourses,addCourse } from './api/Course_api'

function App() {
 const [course,setCourse]=useState([])
 const [title,setTitle]=useState("")
 const [duration,setDuration]=useState("")

 const fetchCourse=async()=>
 {
  const res=await getCourses()
  setCourse(res.data)
 }

 useEffect(()=>
 {
  fetchCourse()
 },[])

 const handleSubmit = async (e) => {
    e.preventDefault()              
    await addCourse({ title, duration })
    setTitle("")
    setDuration("")
    fetchCourse()
  }
  return (
    <>
      <form  onSubmit={handleSubmit}>
        <input type="text" placeholder="Course Title" value={title} onChange={(e) => setTitle(e.target.value)}/>
        <input type="text" placeholder="Duration" value={duration} onChange={(e) => setDuration(e.target.value)}/>
        <button type="Submit">Add Course</button>
      </form>

      
        <ul>
         {
          course.map((courses)=>
          
            <li key={courses._id}> {courses.title}-{courses.duration}</li>
          )
         }
        </ul>
      
    </>
  )
}

export default App
