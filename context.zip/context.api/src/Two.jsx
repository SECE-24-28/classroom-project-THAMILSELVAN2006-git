import React, { useContext } from 'react'
import DataContext from './Context/DataContext'

const Two = () => {
 /* const { name, count } = useContext(DataContext);*/
    const {inc}=useContext(DataContext)
  return (
    /*<div>
      <h1>Employee Name: {name}</h1>
      <p>Age: {count}</p>
    </div>*/
    <div>
      <button onClick={inc}>+</button>
    </div>
  );
};

export default Two;
