import React, { createContext, useState } from "react";

const DataContext = createContext();

export const DataProvider = ({ children }) => {
  /*const [name, setName] = useState("Sachin");
  const [count, setCount] = useState(100);
  const demo = () => "India";*/
  
  const [num,setnum]=useState(100)
  const inc=()=>{
    setnum(num+1)
  }
  const dec=()=>{
    setnum(num-1)
      }

  return (
    /*<DataContext.Provider value={{ name, setName, count, setCount, demo }}>
      {children}
    </DataContext.Provider>*/

    <DataContext.Provider value={{num,setnum,inc,dec}}>
    {children}
    </DataContext.Provider>

  );
};

export default DataContext;
