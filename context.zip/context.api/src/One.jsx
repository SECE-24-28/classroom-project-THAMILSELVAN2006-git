import React, { useContext } from 'react'
import DataContext from './Context/DataContext'

const One = () => {
  /*const { name } = useContext(DataContext);*/
    const { num } = useContext(DataContext);
  return (
   /* <div>
      <h1>Hai {name}</h1>
    </div>*/

    <div>
      <h1>Count:{num}</h1>
    </div>
  );
};

export default One;
