import { useEffect, useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import api from './Api/stu_api'
function App() {
  const [SList,setSList] = useState([])
  useEffect(()=>{
    const fetchData=async()=>{
      try{
        const res=await api.get("/Student")
        setSList(res.data)
      } catch(err){
        console.log(err)
      }
    }
    fetchData();
  },[]);
 
  return (
    <>
    {
     SList.map((stu)=>(
     <p key={stu.Sid}>{stu.Sid}-{stu.sname}-{stu.smark}</p>
     ))
    }
    </>
  );
}

export default App;
