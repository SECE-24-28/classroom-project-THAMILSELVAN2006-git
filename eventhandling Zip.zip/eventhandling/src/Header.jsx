import React from 'react'

const Header = () => {
    let des={backgroundColor:"Black",color:"White"}

  return (
    <div>
        <h1 style={des}>Tiger</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi, culpa quia? Totam sequi hic consequatur necessitatibus ex fuga deserunt in, saepe veniam quas soluta iusto! Repellat iste animi quos assumenda.</p>
    </div>
  )
}

export default Header