import React from 'react'
import './style.css'
const Content = () => {
  return (
    <div className="bg">
       <ol>
        <li>CSE</li>
        <li>EEE</li>
        <li>AIDS</li>
       </ol>
     </div>
  )
}

export default Content