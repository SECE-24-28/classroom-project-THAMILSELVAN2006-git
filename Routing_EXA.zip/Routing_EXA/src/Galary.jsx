import React from 'react'

const Galary = () => {
  return (
    <div>Galary</div>
  )
}

export default Galary