    import React from 'react'

    const NewPost = () => {
    return (
        <div>NewPost</div>
    )
    }

    export default NewPost