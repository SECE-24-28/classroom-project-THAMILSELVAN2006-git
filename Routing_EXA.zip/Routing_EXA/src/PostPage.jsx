import React from 'react'
import { Link, Outlet } from "react-router-dom";
const PostPage = () => {
  return (
    <div>
        <ol>
            <li ><Link to="/PostPage/1">Post 1</Link></li>
            <li ><Link to="/PostPage/2">Post 2</Link></li>
            <li ><Link to="/PostPage/3">Post 3</Link></li>
            <li><Link to="/PostPage/NewPost">NewPost</Link></li>
        </ol>

        <Outlet />
    </div>
  )
}

export default PostPage