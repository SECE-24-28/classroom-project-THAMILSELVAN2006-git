import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Home from './Home'
import About from './About'
import Galary from './Galary'
import PostPage from './PostPage'
import Post from './Post'
import NewPost from './NewPost'
import { Routes, Route, Link } from 'react-router-dom';

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <ul>
      <li><Link to="/">Home</Link></li>
      <li><Link to="/About">About</Link></li>
      <li><Link to="/Galary">Galary</Link></li>
      <li><Link to="/PostPage">PostPage</Link></li>
    </ul>
        <Routes >
          <Route path="/" element={<Home />} />
          <Route path="/About" element={<About />} />
          <Route path="/Galary" element={<Galary />} />
          <Route path="/PostPage" element={<PostPage />} >
              <Route path=":id" element={<Post/>}/>
              <Route path="NewPost" element={<NewPost/>}/>
          </Route>
        </Routes>
    </>
  )
}

export default App