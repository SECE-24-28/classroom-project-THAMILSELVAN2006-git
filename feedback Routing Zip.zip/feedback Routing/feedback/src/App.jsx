import { useContext, useEffect, useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import api from './api/Post'
import Home from './Home'
import Search from './Search'
import AddPost from './AddPost'
import { format } from 'date-fns'
import DataContext, { DataProvider } from './context/DataContext'
import { Link, Route, Routes } from 'react-router-dom'
import EditPost from './EditPost'
function App() {


  return (
    <>
      <ol>
      <li><Link to="/">Home</Link></li>
      <li><Link to="/newpost">NewPost</Link></li>
      
      </ol>

     <Search />

      <Routes>
      <Route path="/" element={<Home />}/>
      <Route path="/newpost" element={<AddPost />}/>
      <Route path="/editpost/:id" element={<EditPost />}/>
      </Routes>
    
     </>
     
  )
}

export default App
