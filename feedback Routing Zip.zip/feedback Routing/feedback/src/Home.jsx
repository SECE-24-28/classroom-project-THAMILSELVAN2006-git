import React, { useContext } from 'react'
import DataContext from './context/DataContext'
import { Link } from 'react-router-dom'
const Home = () => 
    {
        const {searchResult}=useContext(DataContext)
  return (
    <div>
      
        {
        searchResult.map((post)=>
          <div key={post.id}>
        <Link to={`/editpost/${post.id}`} >
        <h1>{post.title}</h1>
        <h3>{post.datetime}</h3>
        <p>{post.body}</p>
        </Link>
        <hr />
        </div>
        )
       }
    </div>
  )
}

export default Home