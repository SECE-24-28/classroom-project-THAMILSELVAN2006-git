import React from 'react'

export const addStudent = () => {
  return (
    <div>
        <form action="">
            <input type="text" placeholder='New Student' ></input>
            <button type="submit">Submit</button>
            <br></br>
        </form>
    </div>
  )
}
