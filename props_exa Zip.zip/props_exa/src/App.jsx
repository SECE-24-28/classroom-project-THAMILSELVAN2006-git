import { use, useEffect, useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Header from './Header'
import Body from './Body'
import Footer from './Footer'

/*function App() {

  const [text, setText] = useState("");

      const [list,setList] =useState([
        {id:1,sname:"Vinoth",fee:true},
        {id:2,sname:"Shiva",fee:false},
        {id:3,sname:"Harish",fee:true}
      ]);

      const handleDelete=(id)=>
      {
      const newList=list.filter((ls)=>ls.id!=id)
      setList(newList)
      }
      const handleCheck=(id)=>
      {
         const newList=list.map((ls)=>(ls.id===id)?({...ls,fee:!ls.fee}):(ls))
         setList(newList)
      }
      
       
      const add=(sname)=>
      {
         const newList=[...list,{id:4,sname,fee:false}] 
         setList(newList)
      }

      const search=(sname)=>
      {
        const newList=list.filter((ls)=>ls.sname.toLowerCase().includes(sname.toLowerCase()))
        setList(newList)
      }

    
  return (
    <>
          <input type="text" placeholder='New Student' ></input>
                <button onClick={()=>add(document.querySelector("input").value)}>Add</button>
               <br></br>
                <input type="text" placeholder='Search Student' value={text}
               onChange={(e) => setText(e.target.value)}></input>
                <button onClick={()=>search(text)}>Search</button>
         <Header title={"Student List"} dept="CSE" year={2025}  />
         <Body list={list} handleDelete={handleDelete} handleCheck={handleCheck} />
         <Footer len={list.length}/>
           
    </>
  )
}*/

function App(){
    const [count,setCount]=useState(0)
    useEffect(()=>{
        console.log("Count:",count)
    },[count]);
  return (
    <>
       <h1>Count:{count}</h1>
       <button onClick={()=>setCount(count+1)}>Increase</button>
    </>
  );
}
/*function App() {

  return(
    <>
    <Header title={"Student List"} dept={"CSE"} year={2025}/>
    </>
  )
}*/

export default App