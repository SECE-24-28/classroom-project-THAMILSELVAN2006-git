import React from 'react'

const Footer = ({ len }) => {
  return (
    <div>
      <h1>Student Count: {len}</h1>
    </div>
  );
};

export default Footer;